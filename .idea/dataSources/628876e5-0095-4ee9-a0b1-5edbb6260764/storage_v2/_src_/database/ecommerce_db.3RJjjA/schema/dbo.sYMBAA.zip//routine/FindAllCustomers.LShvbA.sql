CREATE PROCEDURE FindAllCustomers
AS
SELECT * FROM dbo.tbl_customers 
GO;
go

